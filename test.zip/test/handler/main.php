<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "test");

if(isset($_POST['one']) && isset($_POST['two']) && isset($_POST['free']) && isset($_POST['name']) && isset($_POST['email'])){
  $test_1 = $_POST['one'];
  $test_2 = $_POST['two'];
  $test_3 = $_POST['free'];
  $name = $_POST['name'];
  $email = $_POST['email'];

  $check_sql = "SELECT `id`, `email` FROM `users` WHERE `email` = '$email'";
  $check_q = mysqli_query($db, $check_sql);
  if(!$check_q || (mysqli_num_rows($check_q) > 0)){
    echo "Данные уже занесены!";
  }else{
    $sql1 = "INSERT INTO `users`(`id`, `name`, `email`) VALUES ('','$name','$email')";
    $query = mysqli_query($db, $sql1);

    $sql_u = "SELECT `id` FROM `users` WHERE `email` = '$email' ";
    $query_u = mysqli_query($db, $sql_u);
    $user = mysqli_fetch_assoc($query_u);

    $sql2 = "INSERT INTO `polls`(`id`, `test_1`, `test_2`, `test_3`, `u_id`)
            VALUES ('','$test_1','$test_2','$test_3','{$user['id']}')";
    mysqli_query($db, $sql2);
  }
}else{
  echo "Нет данных";
}
