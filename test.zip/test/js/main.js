function AlertSuccess(){
  $(".alert-success").fadeOut(2000);
}
function AlertDanger(){
  $(".alert-danger").fadeOut(2000);
}


$("#submit").click(function(e){
  e.preventDefault();

  let TestOne = $('input[name="TestAge"]');
  let TestTwo = $('input[name="TestDress"]');
  let TestFree = $('input[name="TestTrend"]');

  if(TestOne[0].checked == false){
    $(".alert-danger").text("Вы неправильно ответили на первый вопрос");
    $(".alert-danger").fadeIn();
    setTimeout(AlertDanger, 3000);
  }
  else if(TestTwo[1].checked == false){
    $(".alert-danger").text("Вы неправильно ответили на второй вопрос");
    $(".alert-danger").fadeIn();
    setTimeout(AlertDanger, 3000);
  }
  else if(TestFree[0].checked == false){
    $(".alert-danger").text("Вы неправильно ответили на третий вопрос");
    $(".alert-danger").fadeIn();
    setTimeout(AlertDanger, 3000);
  }
  else{
    $(".alert-danger").text("Вы неправильно ответили все вопросы");
    $(".alert-danger").fadeIn();
    setTimeout(AlertDanger, 3000);
  }

  if(TestOne[0].checked && TestTwo[1].checked && TestFree[0].checked){
    $(".alert-success").text("На все вопросы вы ответили правильно!");
    $(".alert-success").fadeIn();
    setTimeout(AlertSuccess, 3000);
    if ($('.form-check-input').is(":checked")){
      let one = $('.one').eq(0).val();
      let two = $('.two').eq(1).val();
      let free = $('.free').eq(0).val();
      let name = $('input[name="name"]').val();
      let email = $('input[name="email"]').val();
      $.ajax({
        type: 'post',
        url: '../handler/main.php',
        data: {'one': one, 'two': two, 'free': free, 'name': name, 'email': email},
        success: function(data){
          //
        },
        error: function(){
          console.log("ERROR");
        }
      });
    }
  }else{
    let checkboxes = document.getElementsByClassName('form-check-input');
    let checkboxesChecked = [];
    for (let index = 0; index < checkboxes.length; index++) {
       if (checkboxes[index].checked) {
          checkboxesChecked.push(checkboxes[index].value);
       }
    }
    let one = checkboxesChecked[0];
    let two = checkboxesChecked[1];
    let free = checkboxesChecked[2];
    let name = $('input[name="name"]').val();
    let email = $('input[name="email"]').val();
    $.ajax({
      type: 'post',
      url: '../handler/main.php',
      data: {'one': one, 'two': two, 'free': free, 'name': name, 'email': email},
      success: function(data){
        //
      },
      error: function(){
        console.log("ERROR");
      }
    });
  }
});
